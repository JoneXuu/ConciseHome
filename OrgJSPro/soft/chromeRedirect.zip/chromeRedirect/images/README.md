# License

apps.png, left.png, right.png were created with Android Asset Studio 
and are licensed under the [Creative Commons Attribution 3.0 Unported License](http://creativecommons.org/licenses/by/3.0/), 
which differs from the [MIT License](http://bit.ly/mit-license) of New Tab Redirect itself.

All \*\_32.png images are from [intridea](https://github.com/intridea/authbuttons).

All logos are copyright and trademark their respective companies and are provided here only for means of usage with direct linkage to the respective service.

